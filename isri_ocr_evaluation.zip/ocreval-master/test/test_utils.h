#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#include <text.h>

extern Text* text;

void initialize_texts(void *list);
void deinitialize_texts(void *list);

#endif /* TEST_UTILS_H */
